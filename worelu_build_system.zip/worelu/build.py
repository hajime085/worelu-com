#!/usr/bin/env python3
"""
Worelu ビルドスクリプト
実行: python3 build.py
生成物: public/ 以下に全ファイルを出力

生成するもの:
  - 記事HTML (/articles/{category}/{slug}/index.html)
  - 記事一覧 (/articles/index.html)
  - カテゴリ一覧 (/articles/{category}/index.html)
  - sitemap.xml
  - RSS (feed.xml)
  - robots.txt
"""

import os
import sys
import shutil
import yaml
import markdown
from datetime import datetime, timezone
from pathlib import Path
from jinja2 import Environment, FileSystemLoader

# ===== 設定 =====
BASE_URL = "https://worelu.com"
CONTENT_DIR = Path("content")
TEMPLATE_DIR = Path("templates")
OUTPUT_DIR = Path("public")

CATEGORY_LABELS = {
    "stress":  "症状・ストレス",
    "burnout": "バーンアウト",
    "quit":    "転職・退職",
}

# ===== ユーティリティ =====

def parse_markdown(filepath: Path) -> dict:
    """Markdownファイルをパースしてフロントマターと本文を返す"""
    text = filepath.read_text(encoding="utf-8")

    if not text.startswith("---"):
        print(f"  警告: フロントマターが見つかりません: {filepath}")
        return None

    parts = text.split("---", 2)
    if len(parts) < 3:
        print(f"  警告: フロントマターが不正です: {filepath}")
        return None

    try:
        meta = yaml.safe_load(parts[1])
    except yaml.YAMLError as e:
        print(f"  エラー: YAML解析失敗 {filepath}: {e}")
        return None

    body_md = parts[2].strip()
    md = markdown.Markdown(extensions=["extra", "toc"])
    body_html = md.convert(body_md)

    category = meta.get("category", filepath.parent.name)
    slug = meta.get("slug", filepath.stem)

    return {
        "title":        meta.get("title", ""),
        "description":  meta.get("description", ""),
        "slug":         slug,
        "category":     category,
        "category_label": CATEGORY_LABELS.get(category, category),
        "tags":         meta.get("tags", []),
        "date":         str(meta.get("date", "")),
        "updated":      str(meta.get("updated", meta.get("date", ""))),
        "draft":        meta.get("draft", False),
        "eyecatch":     meta.get("eyecatch", ""),
        "canonical":    meta.get("canonical", f"{BASE_URL}/articles/{category}/{slug}/"),
        "url":          f"/articles/{category}/{slug}/",
        "full_url":     f"{BASE_URL}/articles/{category}/{slug}/",
        "content":      body_html,
    }


def collect_articles() -> list:
    """content/ 以下の全Markdownを収集（draft除外）"""
    articles = []
    for md_file in sorted(CONTENT_DIR.rglob("*.md")):
        art = parse_markdown(md_file)
        if art is None:
            continue
        if art["draft"]:
            print(f"  スキップ（draft）: {md_file}")
            continue
        articles.append(art)

    articles.sort(key=lambda a: a["date"], reverse=True)
    return articles


def get_related(article: dict, all_articles: list, max_count: int = 3) -> list:
    """同じカテゴリの関連記事を返す（自身を除く）"""
    related = [
        a for a in all_articles
        if a["slug"] != article["slug"] and a["category"] == article["category"]
    ]
    if len(related) < max_count:
        others = [
            a for a in all_articles
            if a["slug"] != article["slug"] and a["category"] != article["category"]
        ]
        related += others
    return related[:max_count]


def write_file(path: Path, content: str):
    """ファイルを書き出す（ディレクトリ自動作成）"""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


# ===== 生成処理 =====

def build_articles(env: Environment, articles: list):
    """記事HTMLを生成"""
    tpl = env.get_template("article.html")
    for art in articles:
        related = get_related(art, articles)
        html = tpl.render(**art, related_articles=related)
        out = OUTPUT_DIR / "articles" / art["category"] / art["slug"] / "index.html"
        write_file(out, html)
        print(f"  記事: {out}")


def build_article_list(env: Environment, articles: list):
    """記事一覧ページを生成"""
    tpl = env.get_template("article-list.html")
    cats = [
        {"slug": slug, "label": label}
        for slug, label in CATEGORY_LABELS.items()
    ]
    html = tpl.render(articles=articles, categories=cats)
    out = OUTPUT_DIR / "articles" / "index.html"
    write_file(out, html)
    print(f"  記事一覧: {out}")


def build_category_pages(env: Environment, articles: list):
    """カテゴリ別一覧ページを生成"""
    tpl = env.get_template("article-list.html")
    cats = [
        {"slug": slug, "label": label}
        for slug, label in CATEGORY_LABELS.items()
    ]
    for cat_slug, cat_label in CATEGORY_LABELS.items():
        cat_articles = [a for a in articles if a["category"] == cat_slug]
        if not cat_articles:
            continue
        html = tpl.render(articles=cat_articles, categories=cats)
        out = OUTPUT_DIR / "articles" / cat_slug / "index.html"
        write_file(out, html)
        print(f"  カテゴリ: {out}")


def build_sitemap(articles: list):
    """sitemap.xmlを生成"""
    lines = ['<?xml version="1.0" encoding="UTF-8"?>']
    lines.append('<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">')

    def entry(url, lastmod=None, priority="0.8"):
        lines.append("  <url>")
        lines.append(f"    <loc>{url}</loc>")
        if lastmod:
            lines.append(f"    <lastmod>{lastmod}</lastmod>")
        lines.append(f"    <priority>{priority}</priority>")
        lines.append("  </url>")

    today = datetime.now().strftime("%Y-%m-%d")
    entry(f"{BASE_URL}/", today, "1.0")
    entry(f"{BASE_URL}/articles/", today, "0.9")

    for cat_slug in CATEGORY_LABELS:
        entry(f"{BASE_URL}/articles/{cat_slug}/", today, "0.8")

    for art in articles:
        entry(art["full_url"], art["updated"] or art["date"], "0.7")

    lines.append("</urlset>")
    out = OUTPUT_DIR / "sitemap.xml"
    write_file(out, "\n".join(lines))
    print(f"  sitemap.xml: {out}")


def build_rss(articles: list):
    """RSS (feed.xml) を生成"""
    now = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    lines = ['<?xml version="1.0" encoding="UTF-8"?>']
    lines.append('<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">')
    lines.append("  <channel>")
    lines.append("    <title>Worelu — 仕事で壊れる前に。</title>")
    lines.append(f"    <link>{BASE_URL}</link>")
    lines.append("    <description>仕事のストレス・燃え尽き・転職に関する記事</description>")
    lines.append("    <language>ja</language>")
    lines.append(f"    <lastBuildDate>{now}</lastBuildDate>")
    lines.append(f'    <atom:link href="{BASE_URL}/feed.xml" rel="self" type="application/rss+xml"/>')

    for art in articles[:20]:
        lines.append("    <item>")
        lines.append(f"      <title><![CDATA[{art['title']}]]></title>")
        lines.append(f"      <link>{art['full_url']}</link>")
        lines.append(f"      <guid>{art['full_url']}</guid>")
        lines.append(f"      <description><![CDATA[{art['description']}]]></description>")
        lines.append(f"      <pubDate>{art['date']}</pubDate>")
        lines.append("    </item>")

    lines.append("  </channel>")
    lines.append("</rss>")
    out = OUTPUT_DIR / "feed.xml"
    write_file(out, "\n".join(lines))
    print(f"  feed.xml: {out}")


def build_robots():
    """robots.txtを生成"""
    content = f"""User-agent: *
Allow: /
Disallow: /drafts/

Sitemap: {BASE_URL}/sitemap.xml
"""
    out = OUTPUT_DIR / "robots.txt"
    write_file(out, content)
    print(f"  robots.txt: {out}")


# ===== エントリーポイント =====

def main():
    print("=== Worelu ビルド開始 ===\n")

    if not CONTENT_DIR.exists():
        print("エラー: content/ ディレクトリが見つかりません")
        sys.exit(1)

    if not TEMPLATE_DIR.exists():
        print("エラー: templates/ ディレクトリが見つかりません")
        sys.exit(1)

    # テンプレートエンジン初期化
    env = Environment(loader=FileSystemLoader(str(TEMPLATE_DIR)))

    # 記事収集
    print("記事を収集中...")
    articles = collect_articles()
    print(f"  {len(articles)}本の記事を発見\n")

    if not articles:
        print("警告: 記事が1本もありません")

    # 各種ファイル生成
    print("記事HTMLを生成中...")
    build_articles(env, articles)

    print("\n記事一覧を生成中...")
    build_article_list(env, articles)

    print("\nカテゴリページを生成中...")
    build_category_pages(env, articles)

    print("\nsitemap.xmlを生成中...")
    build_sitemap(articles)

    print("\nRSSを生成中...")
    build_rss(articles)

    print("\nrobots.txtを生成中...")
    build_robots()

    print(f"\n=== ビルド完了: {len(articles)}本の記事を生成しました ===")
    print(f"出力先: {OUTPUT_DIR.resolve()}/")


if __name__ == "__main__":
    main()
